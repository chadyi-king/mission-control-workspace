"""
telegram_listener.py
Full-file replacement — includes:
 - Upstash REST-based Redis pushes (no redis-py socket)
 - Channel ID hard-lock and fuzzy-name fallback
 - Read & persist last 50 messages (rolling)
 - New message listener (only that channel)
 - Tolerant signal detection
 - Local telegram_state.json persistence
"""

import os
import json
import time
import re
import requests
from dotenv import load_dotenv
from telethon import TelegramClient, events

# -----------------------
# Load environment
# -----------------------
load_dotenv()

TELEGRAM_API_ID = int(os.getenv("TELEGRAM_API_ID"))
TELEGRAM_API_HASH = os.getenv("TELEGRAM_API_HASH")
TELEGRAM_PHONE = os.getenv("TELEGRAM_PHONE")
CONTROL_CHAT = os.getenv("CONTROL_CHAT")  # your username (no @)
# Upstash REST (from your .env)
UPSTASH_REDIS_REST_URL = os.getenv("UPSTASH_REDIS_REST_URL")
UPSTASH_REDIS_REST_TOKEN = os.getenv("UPSTASH_REDIS_REST_TOKEN")

# -----------------------
# Channel locking
# -----------------------
# Hard lock ID you provided (fallback)
HARD_LOCK_CHANNEL_ID = -1001623437581

# Fuzzy name keywords required (all must be present in title)
REQUIRED_KEYWORDS = ["callisto", "premium"]

# -----------------------
# Persistence state file
# -----------------------
STATE_FILE = "telegram_state.json"

def load_state():
    try:
        with open(STATE_FILE, "r") as f:
            return json.load(f)
    except Exception:
        return {}

def save_state(state):
    with open(STATE_FILE, "w") as f:
        json.dump(state, f)

# -----------------------
# Upstash REST helpers
# -----------------------
HEADERS = {"Authorization": f"Bearer {UPSTASH_REDIS_REST_TOKEN}"}

def upstash_set(key, value):
    url = f"{UPSTASH_REDIS_REST_URL}/set/{key}"
    try:
        requests.post(url, headers=HEADERS, json={"value": value}, timeout=10)
    except Exception as e:
        print("Upstash SET error:", e)

def upstash_lpush(key, value):
    url = f"{UPSTASH_REDIS_REST_URL}/lpush/{key}"
    try:
        requests.post(url, headers=HEADERS, json={"element": value}, timeout=10)
    except Exception as e:
        print("Upstash LPUSH error:", e)

def upstash_ltrim(key, start=0, stop=49):
    url = f"{UPSTASH_REDIS_REST_URL}/ltrim/{key}"
    try:
        requests.post(url, headers=HEADERS, json={"start": start, "stop": stop}, timeout=10)
    except Exception as e:
        print("Upstash LTRIM error:", e)

def upstash_get(key):
    url = f"{UPSTASH_REDIS_REST_URL}/get/{key}"
    try:
        r = requests.get(url, headers=HEADERS, timeout=10)
        return r.json()
    except Exception as e:
        print("Upstash GET error:", e)
        return None

def upstash_lrange(key, start=0, stop=49):
    url = f"{UPSTASH_REDIS_REST_URL}/lrange/{key}/{start}/{stop}"
    try:
        r = requests.get(url, headers=HEADERS, timeout=10)
        return r.json()
    except Exception as e:
        print("Upstash LRANGE error:", e)
        return None

# -----------------------
# Signal detection (tolerant)
# -----------------------
KEYWORDS = [
    "buy","buys","buying",
    "sell","sells","selling",
    "tp","takeprofit","take profit","takeprofit",
    "sl","stoploss","stop loss",
    "zone","entry","entries","entry-level","entry level"
]

# normalize to remove punctuation and collapse whitespace
def normalize_text(s):
    if not s:
        return ""
    s = s.lower()
    # replace some common punctuation with spaces, collapse multi-space
    s = re.sub(r"[^\w\s]", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s

def tolerant_signal_check(text):
    """
    Return True if text *likely* contains a trading signal.
    Rules:
     - Normalize text
     - Count keyword appearances (substring style)
     - Recognize TP/SL patterns like 'TP1', 'TP 1', 'TP1-TP5'
     - Accept if keyword_count >= 2 OR TP pattern found with a price/number nearby
    """
    if not text:
        return False
    s = normalize_text(text)

    # count keywords
    count = 0
    for k in KEYWORDS:
        if k in s:
            count += 1

    # detect TP pattern (tp followed by digits) or presence of multiple TP tokens
    tp_matches = re.findall(r"\btp\s*\d+", s)
    tp_tokens = len(tp_matches)

    # detect price-like numbers (e.g., 1.1234 or 1234 or 5046)
    price_matches = re.findall(r"\b\d{2,6}(?:\.\d{1,5})?\b", s)
    price_token_count = len(price_matches)

    # If they mention buy/sell plus tp/sl or zone -> strong
    if count >= 2:
        return True

    # If there are multiple TP tokens or TP with numbers -> treat as signal
    if tp_tokens >= 1 and price_token_count >= 1:
        return True

    # fallback: buy/sell with a price-like number
    if any(k in s for k in ["buy","sell","entry","zone"]) and price_token_count >= 1:
        return True

    return False

# -----------------------
# Redis event pushers (structured)
# -----------------------
def push_signal_event(message_id, text, status):
    """
    Stores a per-message record and appends to an event list.
    keys:
      - signals:<message_id>  (JSON)
      - signal_events (list)
    Also stores in 'callisto:messages' list (rolling, capped to 50)
    """
    payload = {
        "timestamp": int(time.time()),
        "message_id": int(message_id) if message_id is not None else None,
        "text": text,
        "status": status
    }
    j = json.dumps(payload)

    # per-message
    upstash_set(f"signals:{message_id}", j)

    # event list (Lpush so newest is first)
    upstash_lpush("signal_events", j)

    # keep last 50 messages for Chad to inspect
    upstash_lpush("callisto:messages", j)
    # trim to 50
    upstash_ltrim("callisto:messages", 0, 49)

# -----------------------
# Telegram client
# -----------------------
client = TelegramClient("quanta_v3", TELEGRAM_API_ID, TELEGRAM_API_HASH)

target_channel_id = None

async def resolve_channel():
    """
    Resolve and persist channel id. Priority:
     1) If state has channel_id -> use it
     2) If dialog.id == HARD_LOCK_CHANNEL_ID -> use it
     3) Fuzzy match dialog titles for required keywords
    """
    global target_channel_id
    state = load_state()
    if state.get("channel_id"):
        try:
            target_channel_id = int(state["channel_id"])
            print("Using persisted channel_id from state:", target_channel_id)
            return
        except Exception:
            pass

    async for dialog in client.iter_dialogs():
        title = (dialog.name or "") or ""
        # hard lock by id if present in the user's account
        if dialog.id == HARD_LOCK_CHANNEL_ID:
            target_channel_id = dialog.id
            print("✅ HARD LOCKED by ID:", title)
            state["channel_id"] = int(dialog.id)
            save_state(state)
            return
        # fuzzy match title
        t = title.lower()
        if all(k in t for k in REQUIRED_KEYWORDS):
            target_channel_id = dialog.id
            print("⚠️ FUZZY MATCH FOUND:", title)
            state["channel_id"] = int(dialog.id)
            save_state(state)
            return

    print("❌ Could not find the target channel in your dialogs. Make sure the account is a member of the channel.")

# -----------------------
# Unified handler used for both old messages and new messages
# -----------------------
async def handle_message_obj(msg_obj, is_old=False):
    """
    msg_obj can be a telethon message object or a dict with 'id' and 'text'
    is_old flag marks whether this is from the prime buffer
    """
    try:
        message_id = int(msg_obj.id) if hasattr(msg_obj, "id") else int(msg_obj.get("id"))
    except Exception:
        message_id = None

    text = getattr(msg_obj, "raw_text", None) or getattr(msg_obj, "message", None) or (msg_obj.get("text") if isinstance(msg_obj, dict) else "")
    text = text or ""

    # update last_processed_message_id locally
    state = load_state()
    last = int(state.get("last_processed_message_id", 0) or 0)
    if message_id and (message_id > last):
        state["last_processed_message_id"] = int(message_id)
        save_state(state)

    # push a detected event
    push_signal_event(message_id, text, "detected_old" if is_old else "detected")

    # decide if it's a trade signal (tolerant)
    is_signal = tolerant_signal_check(text)

    if is_signal:
        push_signal_event(message_id, text, "valid_signal")
        # immediate report to your CONTROL_CHAT (so you get notified)
        try:
            if CONTROL_CHAT:
                await client.send_message(CONTROL_CHAT, f"✅ VALID SIGNAL DETECTED (id={message_id}):\n\n{text}")
        except Exception as e:
            print("Failed to DM CONTROL_CHAT:", e)
    else:
        push_signal_event(message_id, text, "ignored_signal")
        # optional: send smaller notification so Chad knows it was ignored (commented to reduce noise)
        # await client.send_message(CONTROL_CHAT, f"⚠️ IGNORED MESSAGE (id={message_id}):\n\n{text}")

# -----------------------
# Telethon event for new messages
# -----------------------
@client.on(events.NewMessage)
async def _on_new_message(event):
    global target_channel_id
    # ignore non-target channel quickly
    if event.chat_id != target_channel_id:
        return
    # create a minimal object-like wrapper to reuse the same handler
    class M:
        def __init__(self, e):
            self.id = e.message.id
            self.raw_text = getattr(e, "raw_text", "") or e.message.message or ""
    m = M(event)
    await handle_message_obj(m, is_old=False)

# -----------------------
# Main
# -----------------------
async def main():
    print("Connecting to Telegram...")
    await client.start(phone=TELEGRAM_PHONE)
    print("Connected")

    await resolve_channel()
    if not target_channel_id:
        return

    # prime buffer - read last 50 messages and process them (but only once)
    print("📥 Reading last 50 messages (prime buffer)...")
    async for msg in client.iter_messages(target_channel_id, limit=50):
        if not getattr(msg, "raw_text", None) and not getattr(msg, "message", None):
            continue
        await handle_message_obj(msg, is_old=True)

    print("👂 Listening ONLY to CallistoFx Premium Channel...")
    await client.run_until_disconnected()

if __name__ == "__main__":
    with client:
        client.loop.run_until_complete(main())
